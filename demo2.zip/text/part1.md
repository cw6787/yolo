This story originally appeared in the 2009 "Top Shelf Edition" CD reissue of Bloody Kisses. It has been updated for this publishing. 

After burying Brooklyn, New York, under the dense power-dirge cacophony of 1991’s Slow, Deep and Hard, and then recording most of the LP over again as a fake live set for 1992’s The Origin of the Feces — complete with a cover of a rock song popularized by Jimi Hendrix and a close-up of vocalist-bassist-mastermind Peter Steele’s rotten sphincter for the album art — Type O Negative decided to get serious. Or at least as almost serious as Type O could ever be expected to get.

As such, Steele (who was still working for the NYC Parks Department), guitarist Kenny Hickey, drummer Sal Abruscato and producer-keyboardist Josh Silver descended upon Systems Two in Brooklyn to record the album that would propel them to international rock stardom. Originally released on August 17th, 1993, at the tail end of New York City Mayor David Dinkins’ “gorgeous mosaic” of race riots and unemployment, Bloody Kisses offered both a response to the controversy that had enveloped Type O’s debut and an enhanced pop sensibility.

